global.HOST = "127.0.0.1";
global.USER = "kunal";
global.DATABASENAME = "ecommerce";
global.PASSWORD = "kunal";
global.PORT = "3000";
